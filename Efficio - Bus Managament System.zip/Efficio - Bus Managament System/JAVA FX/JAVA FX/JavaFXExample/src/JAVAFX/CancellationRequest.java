package JAVAFX;

public class CancellationRequest {

    private String ticketId;
    private String customerId;
    private String cancellationStatus;

    // Constructor
    public CancellationRequest(String ticketId, String customerId, String cancellationStatus) {
        this.ticketId = ticketId;
        this.customerId = customerId;
        this.cancellationStatus = cancellationStatus;
    }

    // Getters and Setters
    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCancellationStatus() {
        return cancellationStatus;
    }

    public void setCancellationStatus(String cancellationStatus) {
        this.cancellationStatus = cancellationStatus;
    }
}
