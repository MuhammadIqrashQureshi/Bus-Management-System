package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import DBLayer.DataBaseConnection;

public class Route {
    
    private String startStation;
    private String endStation;
    private double distance;
    private String startTime;
    private String endTime;
    private String busNumber;
    private String routeName;

    public Route(String routeName,String startStation, String endStation, double distance, String startTime, String endTime, String busNumber) {
        
    	this.routeName = routeName;
        this.startStation = startStation;
        this.endStation = endStation;
        this.distance = distance;
        this.startTime = startTime;
        this.endTime = endTime;
        this.busNumber = busNumber;
    }

    public boolean addRoute(java.time.LocalDate operationalDate) {
        if (isRouteDuplicate()) {
            showDuplicateAlert();
            return false;
        }

        try (Connection connection = DataBaseConnection.getConnection()) {
          
            String insertRouteQuery = "INSERT INTO Routes (routeName, startStation, endStation, distance, startTime, endTime, busNumber) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement routeStatement = connection.prepareStatement(insertRouteQuery, java.sql.Statement.RETURN_GENERATED_KEYS);

            routeStatement.setString(1, routeName);
            routeStatement.setString(2, startStation);
            routeStatement.setString(3, endStation);
            routeStatement.setDouble(4, distance);
            routeStatement.setString(5, startTime);
            routeStatement.setString(6, endTime);
            routeStatement.setString(7, busNumber);

            int affectedRows = routeStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Failed to insert route, no rows affected.");
            }

            ResultSet generatedKeys = routeStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int routeId = generatedKeys.getInt(1);

                String insertRouteDatesQuery = "INSERT INTO RouteDates (routeId, operationalDate) VALUES (?, ?)";
                PreparedStatement routeDatesStatement = connection.prepareStatement(insertRouteDatesQuery);
                routeDatesStatement.setInt(1, routeId);
                routeDatesStatement.setDate(2, java.sql.Date.valueOf(operationalDate));

                routeDatesStatement.executeUpdate();
                routeDatesStatement.close();
            }
            routeStatement.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    private void showDuplicateAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Duplicate Route");
        alert.setHeaderText("Route already exists");
        alert.setContentText("The route with the same start station, end station, and bus number already exists in the system.");
        alert.showAndWait();
    }


    private boolean isRouteDuplicate() {
        try {
            Connection connection = DataBaseConnection.getConnection();
            String query = "SELECT COUNT(*) FROM Routes WHERE startStation = ? AND endStation = ? AND busNumber = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, startStation);
            statement.setString(2, endStation);
            statement.setString(3, busNumber);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next() && resultSet.getInt(1) > 0) {
                resultSet.close();
                statement.close();
                connection.close();
                return true; 
            }
            resultSet.close();
            statement.close();
            connection.close();
            return false; 
        } catch (SQLException e) {
            e.printStackTrace();
            return true; 
        }
    }
    public static boolean finallyDeleteRoute(String routeName) {
        try (Connection conn = DataBaseConnection.getConnection()) {
            int routeId = -1;
            String busNumber = null;

            String getRouteDetailsQuery = "SELECT routeId, busNumber FROM Routes WHERE routeName = ?";
            try (PreparedStatement getRouteDetailsStmt = conn.prepareStatement(getRouteDetailsQuery)) {
                getRouteDetailsStmt.setString(1, routeName);
                ResultSet rs = getRouteDetailsStmt.executeQuery();
                if (rs.next()) {
                    routeId = rs.getInt("routeId");
                    busNumber = rs.getString("busNumber");
                }
                rs.close();
            }

            if (routeId == -1 || busNumber == null) {
                return false; 
            }

            String deleteRouteDatesQuery = "DELETE FROM RouteDates WHERE routeId = ?";
            try (PreparedStatement deleteRouteDatesStmt = conn.prepareStatement(deleteRouteDatesQuery)) {
                deleteRouteDatesStmt.setInt(1, routeId);
                deleteRouteDatesStmt.executeUpdate();
            }

            String deleteTicketsQuery = "DELETE FROM Tickets WHERE routeId = ?";
            try (PreparedStatement deleteTicketsStmt = conn.prepareStatement(deleteTicketsQuery)) {
                deleteTicketsStmt.setInt(1, routeId);
                deleteTicketsStmt.executeUpdate();
            }
            
            String deleteRouteQuery = "DELETE FROM Routes WHERE routeId = ?";
            try (PreparedStatement deleteRouteStmt = conn.prepareStatement(deleteRouteQuery)) {
                deleteRouteStmt.setInt(1, routeId);
                deleteRouteStmt.executeUpdate();
            }
            
            String updateBusStatusQuery = "UPDATE Bus SET status = 'Available' WHERE busNumber = ?";
            try (PreparedStatement updateBusStatusStmt = conn.prepareStatement(updateBusStatusQuery)) {
                updateBusStatusStmt.setString(1, busNumber); // Use the retrieved busNumber
                updateBusStatusStmt.executeUpdate();
            }

            return true; 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}