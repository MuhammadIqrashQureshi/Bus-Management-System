package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DBLayer.DataBaseConnection;

public class LoggedInPassenger {

    private static String name;
    private static int passengerId;

    public static void setName(String passengerName) {
        name = passengerName;
    }

    public static String getName() {
        return name;
    }

    public static void setPassengerId(int id) {
        passengerId = id;
    }

    public static int getPassengerId() {
        return passengerId;
    }


    
    public void login(String name, String password) {
        String query = "SELECT passengerId, name FROM Passengers WHERE name = ? AND password = ?";
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, password);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("passengerId");
                String passengerName = resultSet.getString("name");
                LoggedInPassenger.setPassengerId(id);
                LoggedInPassenger.setName(passengerName);
                System.out.println("Login successful. Passenger ID: " + id + ", Name: " + passengerName);
            } else {
                System.out.println("Invalid username or password.");
                LoggedInPassenger.setPassengerId(0); // Reset state
                LoggedInPassenger.setName(null);
            }

            resultSet.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
