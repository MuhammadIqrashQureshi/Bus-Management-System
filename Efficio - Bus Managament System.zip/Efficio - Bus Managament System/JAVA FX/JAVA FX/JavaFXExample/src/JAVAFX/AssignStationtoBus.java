package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import DBLayer.DataBaseConnection;

public class AssignStationtoBus {

    @FXML
    private ComboBox<String> stationComboBox;
    @FXML
    private ComboBox<String> busComboBox;

    @FXML
    public void initialize() {
        loadStations();
        loadBuses();
    }


    private void loadStations() {
        ArrayList<String> stations = new ArrayList<>();
        String loggedInManagerName = LoggedInManager.getName();  // Retrieve logged-in manager's name
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                 "SELECT s.name FROM Station s " +
                 "JOIN StationManagerStations sms ON sms.stationName = s.name " +
                 "JOIN StationManager sm ON sm.name = sms.stationManagerName " +
                 "WHERE sm.name = ?")) {

            preparedStatement.setString(1, loggedInManagerName);  // Use the logged-in manager's name

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    stations.add(resultSet.getString("name"));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        stationComboBox.getItems().addAll(stations);
    }

    private void loadBuses() {
        ArrayList<String> buses = new ArrayList<>();
        try (Connection connection = DataBaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT busNumber FROM Bus")) {

            while (resultSet.next()) {
                buses.add(String.valueOf(resultSet.getInt("busNumber")));  // Converting busNumber (INT) to String
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        busComboBox.getItems().addAll(buses);
    }

    @FXML
    private void assignBusToStation() {
        String selectedStation = stationComboBox.getValue();
        String selectedBus = busComboBox.getValue();

        if (selectedStation == null || selectedBus == null) {
            showAlert("Error", "Please select both a station and a bus.");
            return;
        }

        int busNumber = Integer.parseInt(selectedBus);

        try (Connection connection = DataBaseConnection.getConnection()) {
            String checkQuery = "SELECT COUNT(*) FROM StationBusAssignments WHERE stationName = ? AND busNumber = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setString(1, selectedStation);
            checkStatement.setInt(2, busNumber);

            ResultSet resultSet = checkStatement.executeQuery();
            if (resultSet.next() && resultSet.getInt(1) > 0) {
                showAlert("Error", "This bus is already assigned to the selected station.");
                resultSet.close();
                checkStatement.close();
                return;
            }
            resultSet.close();
            checkStatement.close();
            PreparedStatement insertStatement = connection.prepareStatement(
                "INSERT INTO StationBusAssignments (stationName, busNumber) VALUES (?, ?)");
            insertStatement.setString(1, selectedStation);
            insertStatement.setInt(2, busNumber);
            insertStatement.executeUpdate();

            showAlert("Success", "Bus assigned to the station successfully.");
            stationComboBox.getSelectionModel().clearSelection();
            busComboBox.getSelectionModel().clearSelection();
            
            insertStatement.close();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to assign the bus to the station.");
        }
    }

    @FXML
    public void handleBack() {
        try {
           
            Parent stationManagerScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerScreen.fxml"));
            Stage stage = (Stage) stationComboBox.getScene().getWindow();
            stage.setScene(new Scene(stationManagerScreen));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
