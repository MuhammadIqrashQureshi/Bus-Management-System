package JAVAFX;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.fxml.FXML;

import java.awt.Button;
import java.io.IOException;

public class PassengerScreen {
    private Stage stage;
   
    public PassengerScreen(Stage stage) {
        this.stage = stage;
    }

    public Scene createPassengerScene() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerScreen.fxml"));
            return new Scene(root, 600, 400);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

   
}