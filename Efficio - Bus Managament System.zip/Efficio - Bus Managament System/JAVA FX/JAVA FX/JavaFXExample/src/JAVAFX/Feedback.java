package JAVAFX;
import java.sql.Connection;
import java.sql.PreparedStatement;
import DBLayer.DataBaseConnection;

public class Feedback {

	public Feedback() {}
  
	    private int feedbackId;
	    private int passengerId;
	    private int rating;
	    private String feedback;

	    public Feedback(int passengerId, int rating, String feedback) {
	        this.passengerId = passengerId;
	        this.rating = rating;
	        this.feedback = feedback;
	    }
	    public Feedback(int feedbackId,int passengerId, int rating, String feedback) {
	        this.feedbackId = feedbackId;
	    	this.passengerId = passengerId;
	        this.rating = rating;
	        this.feedback = feedback;
	    }

	    public int getFeedbackId() {
	        return feedbackId;
	    }

	    public int getPassengerId() {
	        return passengerId;
	    }

	    public int getRating() {
	        return rating;
	    }

	    public String getFeedback() {
	        return feedback;
	    }
	    
    public void submitFeedbackToDatabase(int passengerId, int rating, String feedback) {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "INSERT INTO Feedback (passengerId, rating, feedback) VALUES (?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, passengerId);
            stmt.setInt(2, rating);
            stmt.setString(3, feedback);
            stmt.executeUpdate();
            System.out.println("Feedback saved successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}