package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBLayer.DataBaseConnection;
import javafx.scene.control.Alert;

public class Admin extends User  {
    

    public Admin() {   super(); }
    
    public Admin(String name, String email, String password, String phonenumber) {
    	  super(name, email, password,phonenumber);
    }
    
    @Override
    public int createAccount() {
        String checkQuery = "SELECT COUNT(*) FROM Admin";
        String insertQuery = "INSERT INTO Admin (name, email, password, phonenumber) VALUES (?, ?, ?, ?)";
        int generatedId = -1;

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
             PreparedStatement insertStatement = connection.prepareStatement(insertQuery, PreparedStatement.RETURN_GENERATED_KEYS)) 
        {
           
            ResultSet resultSet = checkStatement.executeQuery();
            if (resultSet.next() && resultSet.getInt(1) > 0) {
                showAlert("Error","Admin account already exists.",Alert.AlertType.ERROR);
                return -1; 
            }
            insertStatement.setString(1, this.name);
            insertStatement.setString(2, this.email);
            insertStatement.setString(3, this.password);
            insertStatement.setString(4, this.phonenumber);
            int rowsAffected = insertStatement.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet generatedKeys = insertStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    generatedId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to create admin account: " + e.getMessage());
        }
        return generatedId;
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public boolean createAndAddStation(String stationName, String stationLocation, String stationManagerName) {
        Station newStation = new Station(stationName, stationLocation);
        boolean stationInserted = newStation.insertStationIntoDB();
        
        if (!stationInserted) {
            return false; 
        }

        try (Connection connection = DataBaseConnection.getConnection()) {
          
            String checkManagerQuery = "SELECT COUNT(*) FROM StationManagerStations WHERE stationManagerName = ?";
            PreparedStatement checkManagerStatement = connection.prepareStatement(checkManagerQuery);
            checkManagerStatement.setString(1, stationManagerName);
            ResultSet managerResultSet = checkManagerStatement.executeQuery();

            if (managerResultSet.next() && managerResultSet.getInt(1) > 0) {
                return false; 
            }

            String checkStationQuery = "SELECT stationManagerName FROM StationManagerStations WHERE stationName = ?";
            PreparedStatement checkStationStatement = connection.prepareStatement(checkStationQuery);
            checkStationStatement.setString(1, stationName);
            ResultSet stationResultSet = checkStationStatement.executeQuery();

            if (stationResultSet.next()) {
                String existingManagerName = stationResultSet.getString("stationManagerName");
                return false;
            }
            String insertQuery = "INSERT INTO StationManagerStations (stationName, stationManagerName) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, stationName);
            preparedStatement.setString(2, stationManagerName);
            preparedStatement.executeUpdate();

            return true; 
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean managesRoute(String routeName,String startStation, String endStation, String distance,
            String startTime, String endTime, String busNumber,java.time.LocalDate operationalDate) 
    {
    	Route route = new Route(routeName,startStation,endStation,Double.parseDouble(distance),
    			                startTime,endTime,busNumber);
    	return route.addRoute(operationalDate);
    }
    
    
    public boolean deleteRoute(String routeName) {
       
    	return Route.finallyDeleteRoute(routeName);
    }
    

    public boolean deleteStation(String name) {
       
    	return Station.finallyDeleteStation(name);
    }
    
    
    
}