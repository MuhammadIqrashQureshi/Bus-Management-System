package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import DBLayer.DataBaseConnection;
import UI_Controller.PassengerScheduleController;

public class BMS_Controller {
	 private Admin admin; 

	 private String loggedInAdminName; 
	 private int loggedInAdminId;
	 
    public int handleCreateAccount(String name, String email, String password,String phonenumber) {
        Passengers newPassenger = new Passengers(name, email, password,phonenumber);
        return newPassenger.createAccount();
    }
    
    public int handleCreateAccountAdmin(String name, String email, String password,String phonenumber) {
        Admin newAdmin = new Admin(name, email, password,phonenumber);
        return newAdmin.createAccount();
    }
    public int handleCreateAccountStationManager(String name, String email, String password, String phoneNumber) {
        StationManager newStationManager = new StationManager(name, email, password, phoneNumber);
        return newStationManager.createAccount();
    }
    
    public void manageBus(String busNumber, int capacity, String status) {    
        StationManager manager = new StationManager();
        manager.createAndAddBus(busNumber, capacity, status);

    }
    
    public boolean manageStation(String stationName, String stationLocation, String stationManagerName) {
        Admin admin1 = new Admin();
        return admin1.createAndAddStation(stationName, stationLocation, stationManagerName);
    }
    public boolean manageRoute(String routeName, String startStation, String endStation, String distance,
            String startTime, String endTime, String busNumber,LocalDate operationalDate) 
    {

    	Admin admin = new Admin();
    	return admin.managesRoute(routeName, startStation, endStation, distance, startTime, endTime, busNumber,operationalDate);
    }

    public void handleCheckSchedule(String selectedBus, PassengerScheduleController controller) {
        Passengers passenger  = new Passengers();
        passenger.fetchSchedule(selectedBus, controller);
    }
    
    public void submitFeedback(int rating, String feedback) {
        Passengers passenger = new Passengers();
        if (passenger.hasBookedTicket()) {
            passenger.submitFeedback(rating, feedback);
        } else {
           
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Feedback Submission Error");
            alert.setHeaderText(null); 
            alert.setContentText("You must book a ticket before submitting feedback.");

            alert.showAndWait();
        }
    }
    
    public void submitComplaint(String complaintType, String complaintDescription, String stationManager) {
        Passengers passenger = new Passengers();

        if (passenger.hasBookedTicket()) 
        {  
            passenger.lodgeComplaint(complaintType, complaintDescription, stationManager);
        } else {
      
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Complaint Submission Error");
            alert.setHeaderText(null); 
            alert.setContentText("You must book at least one ticket before lodging a complaint.");
            alert.showAndWait();
        }
    }
    
    public boolean deleteBus(String busNumber) {
    	 StationManager manager = new StationManager();
        return manager.deleteBus(busNumber);
    }
    
    
    public boolean deleteRoute(String routeNumber) {
    	 Admin admin = new Admin();
        return admin.deleteRoute(routeNumber);
    }
    
    public boolean deleteStation(String name) {
       Admin admin = new Admin();
       return admin.deleteStation(name);
   }
    
    public boolean authenticateAdmin(String name, String password) {
        String query = "SELECT * FROM Admin WHERE name = ? AND password = ?";
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                loggedInAdminName = resultSet.getString("name");
                loggedInAdminId = resultSet.getInt("adminId");
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phonenumber");
                admin = new Admin(loggedInAdminName, email, password, phoneNumber);

                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error during authentication: " + e.getMessage());
        }
        return false;
    }
    
    public String getLoggedInAdminName() {
        return loggedInAdminName;
    }

    public int getLoggedInAdminId() {
        return loggedInAdminId;
      
    }
    

   
    
}