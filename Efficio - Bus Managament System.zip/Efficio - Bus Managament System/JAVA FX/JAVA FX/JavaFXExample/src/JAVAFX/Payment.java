package JAVAFX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import DBLayer.DataBaseConnection;

public class Payment {
    private String method;
    private String accountOrCardNumber;
    private String transactionCode;

    public Payment(String method, String accountOrCardNumber, String transactionCode) {
        this.method = method;
        this.accountOrCardNumber = accountOrCardNumber;
        this.transactionCode = transactionCode;
    }

    public boolean savePayment() {
        String query = "INSERT INTO Payments (method, accountOrCardNumber, transactionCode) VALUES (?, ?, ?)";
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) 
        {
            preparedStatement.setString(1, this.method);
            preparedStatement.setString(2, this.accountOrCardNumber);
            preparedStatement.setString(3, this.transactionCode);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Failed to save payment: " + e.getMessage());
            return false;
        }
    }
}
