/**
 * 
 */
/**
 * 
 */

module JavaFXExample {
	  requires javafx.controls;
	  requires javafx.graphics;
	  exports JAVAFX;
}