package UI_Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DBLayer.DataBaseConnection;
import JAVAFX.LoggedInPassenger;

public class PassengerBookTicketController {

    @FXML
    private ComboBox<String> busComboBox;
    @FXML
    private TextField seatNumberField;
    @FXML
    private TextField fareField;
    @FXML
    private Button checkAvailableBusesButton;
    @FXML
    private Button bookTicketButton;
    @FXML
    private Button backButton;
    @FXML
    private ComboBox<String> routeComboBox; 
    @FXML
    private ComboBox<String> dateComboBox;



    public void initialize() {
        loadRoutes();
        fareField.setText("500");
        fareField.setEditable(false);
        
        routeComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            showAvailableBuses();
            loadAvailableDates();
        });
        
        dateComboBox.setDisable(true); 
    }

    private void loadRoutes() 
    {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT routeName FROM Routes";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) 
            {
                String routeName = resultSet.getString("routeName");
                routeComboBox.getItems().add(routeName);
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while loading routes.");
        }
    }

    @FXML
    private void showAvailableBuses() 
    {
     
        busComboBox.getItems().clear();
        String selectedRoute = routeComboBox.getValue();

        if (selectedRoute == null) {
            showAlert(Alert.AlertType.ERROR, "Invalid Selection", "Please select both start and end stations and a route.");
            return;
        }

        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT busNumber FROM Routes WHERE routeName = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, selectedRoute);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String busNumber = resultSet.getString("busNumber");
                busComboBox.getItems().add(busNumber);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while loading available buses.");
        }
    }

    private void loadAvailableDates() {
        String selectedRoute = routeComboBox.getValue();
        
        if (selectedRoute == null) {
            showAlert(Alert.AlertType.ERROR, "Invalid Selection", "Please select a route.");
            return;
        }
        
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT operationalDate FROM RouteDates WHERE routeId = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, getRouteId(selectedRoute));
            ResultSet resultSet = statement.executeQuery();

            dateComboBox.getItems().clear();  
            
            while (resultSet.next()) {
                String date = resultSet.getString("operationalDate");
                dateComboBox.getItems().add(date);
            }

            dateComboBox.setDisable(false); 
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while loading available dates.");
        }
    }
    
    private boolean openPaymentScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("TicketPayment.fxml"));
            Parent paymentRoot = loader.load();

           
            Stage paymentStage = new Stage();
            paymentStage.setTitle("Make Payment");
            paymentStage.setScene(new Scene(paymentRoot));
            PaymentController paymentController = loader.getController();
            paymentStage.showAndWait();
            return paymentController.isPaymentSuccessful();
            
        } catch (IOException e) {
            System.out.println("Failed to load Payment screen: " + e.getMessage());
            return false;
        }
    }

    @FXML
    private void handleBookTicket() {
        String selectedBus = busComboBox.getValue();
        String selectedRoute = routeComboBox.getValue();
        String selectedDate = dateComboBox.getValue();

        if (selectedBus == null || selectedRoute == null || selectedDate == null) {
            showAlert(Alert.AlertType.ERROR, "Missing Information", "Please fill in all required fields.");
            return;
        }

        try (Connection connection = DataBaseConnection.getConnection()) {
            int passengerId = LoggedInPassenger.getPassengerId();

            String checkQuery = "SELECT COUNT(*) FROM Tickets WHERE passengerId = ? AND bookingDate = ? AND routeId = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setInt(1, passengerId);
            checkStatement.setString(2, selectedDate);
            checkStatement.setInt(3, getRouteId(selectedRoute));
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next() && resultSet.getInt(1) > 0) {
                showAlert(Alert.AlertType.ERROR, "Duplicate Booking", "You already have a ticket booked for this route and date. Please select another date or route.");
                return;
            }

            int busId = getBusId(selectedBus);
            int bookedSeats = getBookedSeats(busId, selectedDate);
            int capacity = getBusCapacity(busId);

            if (bookedSeats >= capacity) {
                showAlert(Alert.AlertType.ERROR, "Bus Full", "No seats available on this bus.");
                return;
            }

            int seatNumber = bookedSeats + 1;

            boolean paymentSuccess = openPaymentScreen();

            if (paymentSuccess) {
              
                String insertQuery = "INSERT INTO Tickets (passengerId, routeId, busId, bookingDate, seatNumber, fare) VALUES (?, ?, ?, ?, ?, 500)";
                PreparedStatement statement = connection.prepareStatement(insertQuery);
                statement.setInt(1, passengerId);
                statement.setInt(2, getRouteId(selectedRoute));
                statement.setInt(3, busId);
                statement.setString(4, selectedDate);
                statement.setInt(5, seatNumber);
                statement.executeUpdate();

                showAlert(Alert.AlertType.INFORMATION, "Booking Successful", "Your ticket has been booked successfully!\nSeat Number: " + seatNumber);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while booking the ticket.");
        }
    }

    /**
     * Get the total booked seats for a bus on a specific date.
     */
    private int getBookedSeats(int busId, String date) throws SQLException {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT COUNT(*) AS bookedSeats FROM Tickets WHERE busId = ? AND bookingDate = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, busId);
            statement.setString(2, date);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("bookedSeats");
            } else {
                return 0;
            }
        }
    }

    private int getBusCapacity(int busId) throws SQLException {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT capacity FROM Bus WHERE busId = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, busId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("capacity");
            } else {
                throw new SQLException("Bus not found.");
            }
        }
    }


    private int getRouteId(String routeName) throws SQLException {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT routeId FROM Routes WHERE routeName = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, routeName);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("routeId");
            } else {
                throw new SQLException("Route not found.");
            }
        }
    }

    private int getBusId(String busNumber) throws SQLException {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT busId FROM Bus WHERE busNumber = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, busNumber);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("busId");
            } else {
                throw new SQLException("Bus not found.");
            }
        }
    }

    @FXML
    private void goBackToPassengerScreen() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e)            {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
