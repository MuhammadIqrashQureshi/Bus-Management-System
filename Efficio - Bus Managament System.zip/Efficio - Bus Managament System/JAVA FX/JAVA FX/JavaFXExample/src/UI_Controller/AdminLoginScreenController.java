package UI_Controller;

import java.io.IOException;

import JAVAFX.BMS_Controller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminLoginScreenController 
{
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private Button backButton;

    @FXML
    private void handleLogin() 
    {
        
        String name = nameTextField.getText();
        String password = passwordTextField.getText();

        if (name.isEmpty() || password.isEmpty()) 
        {
            showAlert("Missing Field","Name and password fields cannot be empty for login.", Alert.AlertType.ERROR);
            return;
        }

        
        BMS_Controller bmsController = new BMS_Controller();
        boolean loginSuccessful = bmsController.authenticateAdmin(name, password);

        if (loginSuccessful) 
        {
        	showAlert("Success","Login Successful.", Alert.AlertType.INFORMATION);  
            navigateToScreen("/FXML_FILES/AdminScreen.fxml");
        } 
        else 
        {

            showAlert("Login Error","Invalid login credentials. Please try again.", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleBackButton() {
        try {
           
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/main.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(adminScreen, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
    
	@FXML
    private void handleCreateAccount() {
        navigateToScreen("/FXML_FILES/AdminCreateAccountScreen.fxml");
    }

    private void navigateToScreen(String fxmlFile) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
            Stage stage = (Stage) nameTextField.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}