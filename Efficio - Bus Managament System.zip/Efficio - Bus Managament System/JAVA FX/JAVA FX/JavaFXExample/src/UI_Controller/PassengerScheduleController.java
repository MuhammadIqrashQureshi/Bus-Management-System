package UI_Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;

public class PassengerScheduleController {

    @FXML
    private ComboBox<String> EnterstartStationField;
    @FXML
    private ComboBox<String> EnterendStationField;
    @FXML
    private ComboBox<String> busComboBox;
    @FXML
    private TextField distanceField;
    @FXML
    private TextField startTimeField;
    @FXML
    private TextField endTimeField;
 
    @FXML
    private Button showAvailableBusesButton;  
    @FXML
    private Button checkScheduleButton;
    @FXML
    private Button backButton;
    
    private ObservableList<String> busList = FXCollections.observableArrayList();

    public void initialize() {
        loadStations();
    }

    private void loadStations() {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT DISTINCT name FROM Station";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String station = resultSet.getString("name");
                EnterstartStationField.getItems().add(station);
                EnterendStationField.getItems().add(station);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Database Error", "An error occurred while loading stations.");
        }
    }
    @FXML
    private void showAvailableBuses() {
        String startStation = EnterstartStationField.getValue();
        String endStation = EnterendStationField.getValue();

        if (startStation == null || endStation == null) {
            showAlert(AlertType.ERROR, "Invalid Selection", "Please select both start and end stations.");
            return;
        }

        busList.clear();
        try (Connection connection = DataBaseConnection.getConnection()) {
            String query = "SELECT busNumber FROM Routes WHERE startStation = ? AND endStation = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, startStation);
            statement.setString(2, endStation);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                busList.add(resultSet.getString("busNumber"));
            }
            busComboBox.setItems(busList);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Database Error", "An error occurred while loading available buses.");
        }
    }

    @FXML
    private void handleCheckSchedule() {
        String selectedBus = busComboBox.getValue();

        if (selectedBus == null) {
            showAlert(AlertType.ERROR, "No Bus Selected", "Please select a bus.");
            return;
        }

        BMS_Controller bmsController = new BMS_Controller();
        bmsController.handleCheckSchedule(selectedBus, this);
    }

    public void updateScheduleFields(double distance, String startTime, String endTime) {
        
        distanceField.setText(String.valueOf(distance));
        startTimeField.setText(startTime);
        endTimeField.setText(endTime);
    }
    public void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    
    @FXML
    private void goBackToPassengerScreen() {
        try {
         
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/PassengerScreen.fxml"));
            
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400); 
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
