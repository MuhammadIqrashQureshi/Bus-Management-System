package UI_Controller;
import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;
import JAVAFX.LoggedInManager;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BusController {
    
	@FXML
    private TextField busIdField;
    @FXML
    private TextField busNumberTextField;
    @FXML
    private TextField capacityTextField;
    @FXML
    private TextField statusTextField;
    @FXML
    private ComboBox<String> stationComboBox; 

    @FXML
    private void addBus() {
        String busNumber = busNumberTextField.getText();
        String capacityText = capacityTextField.getText();
        String status = statusTextField.getText();
        if (busNumber.isEmpty() || capacityText.isEmpty() || status.isEmpty()) {
            showAlert("Error", "All fields must be filled.");
            return;
        }

        try {
          
            int capacity = Integer.parseInt(capacityText);
            BMS_Controller bmsController = new BMS_Controller();
            bmsController.manageBus(busNumber, capacity, status);
            showAlert("Success", "Bus added successfully.");

            busNumberTextField.clear();
            capacityTextField.clear();
            statusTextField.clear();

        } catch (NumberFormatException e) {
            
            showAlert("Error", "Capacity must be a valid number.");
        }
    }
    
    @FXML
    public void initialize() {

        ArrayList<String> stations = getStationsForStationManager();
        if (stations != null) {
            stationComboBox.getItems().addAll(stations);
        }
    }

    private ArrayList<String> getStationsForStationManager() {
        ArrayList<String> stations = new ArrayList<>();
        
        try {
           
            String managerName = LoggedInManager.getName();
            System.out.println("Name="+ managerName);
            Connection connection = DataBaseConnection.getConnection();
            Statement statement = connection.createStatement();

            String query = "SELECT stationName FROM StationManagerStations WHERE stationManagerName = '" + managerName + "'";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                stations.add(resultSet.getString("stationName"));
            }

            resultSet.close();
            statement.close();
            connection.close();
            
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load stations: " + e.getMessage());
        }
        return stations;
    }

    
    @FXML
    private void goBackToStationManagerScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/StationManagerScreen.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) busNumberTextField.getScene().getWindow();
            stage.setTitle("Station Manager");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load StationManager.fxml: " + e.getMessage());
        }
    }

  
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

