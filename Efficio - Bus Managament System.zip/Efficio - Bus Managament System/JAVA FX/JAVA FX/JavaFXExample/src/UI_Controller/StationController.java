package UI_Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;

public class StationController {

    @FXML
    private TextField nameField;
    @FXML
    private TextField locationField;
    @FXML
    private ComboBox<String> stationManagerComboBox; 
    private BMS_Controller bmsController = new BMS_Controller();

    
    @FXML
    public void initialize() 
    {
        
        ArrayList<String> managerNames = getStationManagerNamesFromDB();
        if (managerNames != null) {
            stationManagerComboBox.getItems().addAll(managerNames);
        }
    }

    private ArrayList<String> getStationManagerNamesFromDB() {
        ArrayList<String> managerNames = new ArrayList<>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try 
        {
            connection = DataBaseConnection.getConnection();
            statement = connection.createStatement();
            String query = "SELECT name FROM StationManager"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                managerNames.add(name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return managerNames;
    }
    
    @FXML
    private void handleAddStation() {
        String stationName = nameField.getText();
        String location = locationField.getText();
        String selectedManagerName = stationManagerComboBox.getValue();

        if (stationName.isEmpty() || location.isEmpty() || selectedManagerName == null) {
            showAlert("Error", "All fields must be filled, and a Station Manager must be selected.");
            return;
        }

        boolean isAddedSuccessfully = bmsController.manageStation(stationName, location, selectedManagerName);

        if (isAddedSuccessfully) {
            showAlert("Success", "Station and assignment added successfully.");
            nameField.clear();
            locationField.clear();
            stationManagerComboBox.getSelectionModel().clearSelection();
        } else {
            showAlert("Error", "Failed to add the station and assignment. Please check the conditions.");
        }
    }


    @FXML
    private void handleBack() {
        try {
            // Load the AdminScreen FXML
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            Stage stage = (Stage) nameField.getScene().getWindow();
            Scene scene = new Scene(adminScreen, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}