package UI_Controller;

import DBLayer.DataBaseConnection;
import JAVAFX.LoggedInPassenger;
import JAVAFX.Ticket;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CancelTicketController {
    
    @FXML
    private TextField ticketIdField; 
    @FXML
    private Button cancelTicketButton;
    @FXML
    private Button backButton;

    @FXML
    void handleCancelTicket() {

        int passengerId = LoggedInPassenger.getPassengerId(); 
        String ticketId = ticketIdField.getText();

        if (ticketId.isEmpty()) {
            showAlert("Error", "Ticket ID is required! Please enter a valid ticket ID.");
            return;
        }
        
        if (!Ticket.isTicketIdValid(ticketId)) {
            showAlert("Error", "Invalid Ticket ID! No ticket found with the entered ID.");
            return;
        }

        if (!Ticket.isTicketOwnedByPassenger(ticketId, passengerId)) {
            showAlert("Error", "You can only cancel your own tickets.");
            return;
        }

        boolean requestSent = sendCancellationRequest(ticketId, passengerId);

        if (requestSent) {
            showAlert("Success", "Your cancellation request has been sent to the Station Manager.");
        } else {
            showAlert("Error", "There was an issue sending your cancellation request. Please try again.");
        }
    }

    public boolean sendCancellationRequest(String ticketId, int passengerId) {
        String query = "INSERT INTO cancelled_tickets (ticket_id, passengerId, cancellation_status) " +
                       "VALUES (?, ?, 'Pending')";

        try (Connection connection = DataBaseConnection.getConnection(); 
             PreparedStatement stmt = connection.prepareStatement(query)) {
            
            stmt.setString(1, ticketId);  
            stmt.setInt(2, passengerId);     

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    @FXML
    private void handleBackButton() {
        try {
    
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/viewBookings.fxml"));
            Parent passengerScreen = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();

            stage.setScene(new Scene(passengerScreen));
            stage.setTitle("Booking Screen");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Unable to load Passenger Screen. Please try again.");
        }
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}