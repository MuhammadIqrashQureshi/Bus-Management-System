package UI_Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import DBLayer.DataBaseConnection;

public class AssignManagerController {

    @FXML
    private ComboBox<String> stationComboBox;
    @FXML
    private ComboBox<String> managerComboBox;

    @FXML
    public void initialize() {
        
        loadStations();
        loadManagers();
    }

    private void loadStations() {
        ArrayList<String> stations = new ArrayList<>();
        try (Connection connection = DataBaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT name FROM Station")) {

            while (resultSet.next()) {
                stations.add(resultSet.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        stationComboBox.getItems().addAll(stations);
    }

    private void loadManagers() {
        ArrayList<String> managers = new ArrayList<>();
        try (Connection connection = DataBaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT name FROM StationManager")) {

            while (resultSet.next()) {
                managers.add(resultSet.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        managerComboBox.getItems().addAll(managers);
    }
    
    @FXML
    private void assignManager() {
        String selectedStation = stationComboBox.getValue();
        String selectedManager = managerComboBox.getValue();

        if (selectedStation == null || selectedManager == null) {
            showAlert("Error", "Please select both a station and a manager.");
            return;
        }

        // Check if the station is already assigned to a manager
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement checkStationStmt = connection.prepareStatement(
                 "SELECT stationManagerName FROM StationManagerStations WHERE stationName = ?")) {

            checkStationStmt.setString(1, selectedStation);
            ResultSet stationResultSet = checkStationStmt.executeQuery();

            if (stationResultSet.next()) {
                String currentManager = stationResultSet.getString(1);
                if (currentManager.equals(selectedManager)) {
                    //selected manager --> already assigned to select station
                    showAlert("Error", "This station is already assigned to this manager.");
                    return;
                } else {
                    // The station is already assigned to a different manager, confirm the reassignment
                    showAlert("Confirmation", "This station is currently assigned to a different manager.");
                }
            } 
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to check manager's current station assignment.");
            return;
        }

        // manager is already --->  another station
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement checkManagerStmt = connection.prepareStatement(
                 "SELECT COUNT(*) FROM StationManagerStations WHERE stationManagerName = ?")) {

            checkManagerStmt.setString(1, selectedManager);
            ResultSet managerResultSet = checkManagerStmt.executeQuery();

            if (managerResultSet.next() && managerResultSet.getInt(1) > 0) {
                showAlert("Error", "This manager is already assigned to another station.");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to check manager's station assignments.");
            return;
        }

        // manager ---> to the selected station
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                 "INSERT INTO StationManagerStations (stationName, stationManagerName) VALUES (?, ?)")) {

            preparedStatement.setString(1, selectedStation);
            preparedStatement.setString(2, selectedManager);
            preparedStatement.executeUpdate();

            showAlert("Success", "Manager assigned to the station successfully.");
            stationComboBox.getSelectionModel().clearSelection();
            managerComboBox.getSelectionModel().clearSelection();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to assign the manager to the station.");
        }
    }


    
    @FXML
    public void handleBack() {
        try {
           
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            Stage stage = (Stage) stationComboBox.getScene().getWindow();
            stage.setScene(new Scene(adminScreen));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}