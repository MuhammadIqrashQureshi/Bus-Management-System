package UI_Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBLayer.DataBaseConnection;
import JAVAFX.BMS_Controller;

public class AdminDeleteRouteController {

    @FXML
    private ComboBox<String> routeComboBox;

    @FXML
    private Button deleteButton;

    @FXML
    private Button backButton;

    // Fetch all routes from the Routes table
    public List<String> getAvailableRoutes() {
        List<String> availableRoutes = new ArrayList<>();
        try (Connection conn = DataBaseConnection.getConnection()) {
            String query = "SELECT routeName FROM Routes"; 
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                availableRoutes.add(rs.getString("routeName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return availableRoutes;
    }

    @FXML
    public void initialize() {
        // Populate the routeComboBox with available routes
        ObservableList<String> availableRoutes = FXCollections.observableArrayList(getAvailableRoutes());
        routeComboBox.setItems(availableRoutes);
    }

    @FXML
    public void deleteSelectedRoute() {
        String selectedRoute = routeComboBox.getValue();
        if (selectedRoute == null) {
            showAlert("Error", "No route selected!", Alert.AlertType.ERROR);
            return;
        }

        BMS_Controller bmsController =  new BMS_Controller();
        boolean isDeleted = bmsController.deleteRoute(selectedRoute);

        if (isDeleted) {
            showAlert("Success", "Route deleted successfully!", Alert.AlertType.INFORMATION);
            routeComboBox.getItems().remove(selectedRoute);
        } else {
            showAlert("Error", "Route could not be deleted!", Alert.AlertType.ERROR);
        }
    }
    
    @FXML
    private void goBackAdminScreen() {
        try {
          
            Parent adminScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(adminScreen, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}