package UI_Controller;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;

import javafx.scene.Node;

import javafx.util.Duration;


public class AdminController {

	@FXML
	private Button createAccountButton;
    
	@FXML
	private Button addStationButton;
	@FXML
	private Button assignManagerButton;
	@FXML
	private Button addRoutesButton;
	@FXML
	private Button Review;
	@FXML
	private Button backButton;
	@FXML
	private Button deleteRouteButton;
	@FXML
	private Button deleteStationButton;
	
	 @FXML
	    public void initialize() {
	        // Apply fade-in animation to all buttons
	        fadeInButton(createAccountButton);
	        fadeInButton(addStationButton);
	        fadeInButton(assignManagerButton);
	        fadeInButton(addRoutesButton);
	        fadeInButton(Review);
	        fadeInButton(deleteRouteButton);
	        fadeInButton(deleteStationButton);
	        fadeInButton(backButton);
	    }

	    private void fadeInButton(Node node) {
	        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), node);
	        fadeIn.setFromValue(0.0);
	        fadeIn.setToValue(1.0); 
	        fadeIn.setCycleCount(1);
	        fadeIn.setAutoReverse(false);
	        fadeIn.play();
	    }
	    
	@FXML
    private void openCreateAccountScreen() {
        try {
        	
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AdminCreateAccountScreen.fxml"));
            Parent root = loader.load();
        	Stage stage = (Stage) createAccountButton.getScene().getWindow();
            Scene scene = new Scene(root, 600, 400);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	@FXML
	 private void openStationScreen() {
	        try {
	           
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/Station.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) addStationButton.getScene().getWindow();
	            Scene scene = new Scene(root,600,400);
	            stage.setScene(scene);
	            stage.show();

	        } catch (IOException e) {
	            e.printStackTrace();
	            System.out.println("Error loading the station screen.");
	        }
	    }
	
	 @FXML
	    private void openAssignManagerScreen() {
	        try {
	            
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AssignManager.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) assignManagerButton.getScene().getWindow();
	            stage.setTitle("Assign Manager to Station");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	 @FXML
	    private void openAddRoutesScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AdminAddRoute.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) addRoutesButton.getScene().getWindow();
	            Scene scene = new Scene(root, 600, 400);
	            stage.setScene(scene);
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	            System.out.println("Error loading the add routes screen.");
	        }
	    }
	 
	 @FXML
	    private void openAdminReivewScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AdminReview.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) Review.getScene().getWindow();
	            Scene scene = new Scene(root, 800, 700);
	            stage.setScene(scene);
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	            System.out.println("Error loading the Admin Review screen.");
	        }
	    }
	 
	    @FXML
	    private void openDeleteRouteScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AdminDeleteRoute.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) deleteRouteButton.getScene().getWindow();
	            stage.setTitle("Review Comlpaint");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    @FXML
	    private void openDeleteStationScreen() {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML_FILES/AdminDeleteStation.fxml"));
	            Parent root = loader.load();
	            Stage stage = (Stage) deleteStationButton.getScene().getWindow();
	            stage.setTitle("Review Comlpaint");
	            stage.setScene(new Scene(root));
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    
	 @FXML
	    private void goBackToMainScreen() {
	        try {

	            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/main.fxml"));
	            Stage stage = (Stage) backButton.getScene().getWindow();
	            Scene scene = new Scene(root, 600, 400);
	            stage.setScene(scene);
	            stage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	 
}