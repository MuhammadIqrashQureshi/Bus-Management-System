package UI_Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DBLayer.DataBaseConnection;
import JAVAFX.CancellationRequest;
import JAVAFX.LoggedInManager;

public class ApproveCancellationController {

    @FXML
    private TableView<CancellationRequest> cancellationRequestsTable;
    @FXML
    private TableColumn<CancellationRequest, String> ticketIdColumn;
    @FXML
    private TableColumn<CancellationRequest, String> customerIdColumn;
    @FXML
    private TableColumn<CancellationRequest, String> cancellationStatusColumn;

    @FXML
    private Button approveButton;
    
    @FXML
    private Button backButton;

    @FXML
    private void initialize() {
       
        ticketIdColumn.setCellValueFactory(new PropertyValueFactory<>("ticketId"));
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        cancellationStatusColumn.setCellValueFactory(new PropertyValueFactory<>("cancellationStatus"));
        loadCancellationRequests();
    }

    private void loadCancellationRequests() {
        String managerName = LoggedInManager.getName(); 

        if (managerName == null || managerName.isEmpty()) {
            showAlert("Error", "Manager is not logged in.");
            return;
        }
        String query = "SELECT ct.ticket_id, ct.passengerId, ct.cancellation_status " +
                "FROM cancelled_tickets ct " +
                "INNER JOIN tickets t ON ct.ticket_id = t.ticketId " +
                "INNER JOIN Routes r ON t.routeId = r.routeId " +
                "INNER JOIN Station s ON s.name = r.startStation " + 
                "INNER JOIN StationManagerStations sms ON s.name = sms.stationName " +
                "WHERE sms.stationManagerName = ? AND ct.cancellation_status = 'Pending'";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setString(1, managerName); 
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String ticketId = rs.getString("ticket_id");
                String customerId = rs.getString("passengerId");
                String cancellationStatus = rs.getString("cancellation_status");

                // Add the request to the table
                cancellationRequestsTable.getItems().add(new CancellationRequest(ticketId, customerId, cancellationStatus));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load cancellation requests.");
        }
    }

    // Method to handle the approve button click event
    @FXML
    private void handleApproveCancellation() {
        // Get the selected cancellation request
        CancellationRequest selectedRequest = cancellationRequestsTable.getSelectionModel().getSelectedItem();
        if (selectedRequest != null) {
            boolean success = approveCancellationRequest(selectedRequest.getTicketId());
            if (success) {
                showAlert("Cancellation Approved", "The cancellation request has been approved.");
                // Refresh the table after approval
                cancellationRequestsTable.getItems().remove(selectedRequest);
            } else {
                showAlert("Error", "Failed to approve the cancellation request.");
            }
        } else {
            showAlert("No Selection", "Please select a cancellation request to approve.");
        }
    }

    private boolean approveCancellationRequest(String ticket_id) {
        String deleteCancelledTicketQuery = "DELETE FROM cancelled_tickets WHERE ticket_id = ?";
        String deleteTicketQuery = "DELETE FROM tickets WHERE ticketId = ?";

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement deleteCancelledStmt = connection.prepareStatement(deleteCancelledTicketQuery);
             PreparedStatement deleteTicketStmt = connection.prepareStatement(deleteTicketQuery)) {

            deleteCancelledStmt.setString(1, ticket_id);
            int rowsAffectedCancelled = deleteCancelledStmt.executeUpdate();

            if (rowsAffectedCancelled > 0) 
            {
                deleteTicketStmt.setString(1, ticket_id);
                int rowsAffectedTicket = deleteTicketStmt.executeUpdate();
                return rowsAffectedTicket > 0;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @FXML
    public void handleBackAction() {
        try {
           
            Parent stationManagerScreen = FXMLLoader.load(getClass().getResource("/FXML_FILES/StationManagerScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(stationManagerScreen));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
