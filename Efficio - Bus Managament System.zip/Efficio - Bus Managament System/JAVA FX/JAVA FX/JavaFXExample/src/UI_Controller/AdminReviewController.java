package UI_Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DBLayer.DataBaseConnection;
import JAVAFX.Complaint;
import JAVAFX.Feedback;

public class AdminReviewController {

    @FXML
    private Button backButton;

    @FXML
    private TableView<Feedback> feedbackTable;

    @FXML
    private TableView<Complaint> complaintsTable;

    @FXML
    private TableColumn<Feedback, Integer> feedbackIDColumn;
    
    @FXML
    private TableColumn<Feedback, Integer> ratingColumn;

    @FXML
    private TableColumn<Feedback, String> passengerNameColumn;

    @FXML
    private TableColumn<Feedback, String> feedbackDescriptionColumn;

    @FXML
    private TableColumn<Complaint, Integer> complaintIDColumn;

    @FXML
    private TableColumn<Complaint, String> passengerNameComplaintsColumn;

    @FXML
    private TableColumn<Complaint, String> complaintTypeColumn;

    @FXML
    private TableColumn<Complaint, String> complaintDescriptionColumn;

    public void initialize() {
        
    	feedbackIDColumn.setCellValueFactory(new PropertyValueFactory<>("feedbackId"));
    	passengerNameColumn.setCellValueFactory(new PropertyValueFactory<>("passengerId")); 
    	ratingColumn.setCellValueFactory(new PropertyValueFactory<>("rating"));
    	feedbackDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("feedback"));

        complaintIDColumn.setCellValueFactory(new PropertyValueFactory<>("complaintId"));
        passengerNameComplaintsColumn.setCellValueFactory(new PropertyValueFactory<>("passengerId"));
        complaintTypeColumn.setCellValueFactory(new PropertyValueFactory<>("complaintType"));
        complaintDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("complaintDescription"));

        loadFeedbacks();
        loadComplaints();
    }

    private void loadFeedbacks() {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String sql = "SELECT * FROM Feedback"; 
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int feedbackID = resultSet.getInt("feedbackId");
                int passengerId = resultSet.getInt("passengerId");
                int rating = resultSet.getInt("rating");
                String feedbackDescription = resultSet.getString("feedback");

                Feedback feedback = new Feedback(feedbackID,passengerId, rating, feedbackDescription);
                feedbackTable.getItems().add(feedback);
            }

        } catch (SQLException e) {
            showError("Error loading feedbacks", e.getMessage());
        }
    }

    private void loadComplaints() {
        try (Connection connection = DataBaseConnection.getConnection()) {
            String sql = "SELECT * FROM Complaints";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int complaintID = resultSet.getInt("complaintId");
                int passengerId = resultSet.getInt("passengerId");
                String complaintType = resultSet.getString("complaintType");
                String complaintDescription = resultSet.getString("complaintDescription");

                Complaint complaint = new Complaint(complaintID,passengerId, complaintType, complaintDescription, null);
                complaintsTable.getItems().add(complaint);
            }

        } catch (SQLException e) {
            showError("Error loading complaints", e.getMessage());
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void goBackToAdminScreen() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/FXML_FILES/AdminScreen.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(root, 500, 600);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}